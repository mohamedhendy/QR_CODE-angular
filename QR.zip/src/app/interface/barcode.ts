export interface barCodeType  {
    QRCode: {
        qrImage: string
    }
}