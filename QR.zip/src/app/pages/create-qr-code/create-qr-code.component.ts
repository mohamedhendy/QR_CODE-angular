import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-create-qr-code',
  templateUrl: './create-qr-code.component.html',
  styleUrls: ['./create-qr-code.component.scss']
})
export class CreateQrCodeComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }

}
