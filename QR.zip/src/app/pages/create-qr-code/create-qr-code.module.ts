import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateQrCodeRoutingModule } from './create-qr-code-routing.module';
import { CreateQrCodeComponent } from './create-qr-code.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { QRTypeButtonsComponent } from 'src/app/components/qrtype-buttons/qrtype-buttons.component';
import { BarcodeComponent } from 'src/app/components/barcode/barcode.component';
import { DesignBarcodeComponent } from 'src/app/components/design-barcode/design-barcode.component';
@NgModule({
  declarations: [
    CreateQrCodeComponent,
    BarcodeComponent,
    QRTypeButtonsComponent,
    DesignBarcodeComponent
  ],
  imports: [
    CommonModule,
    CreateQrCodeRoutingModule,
      FormsModule,
    ReactiveFormsModule
  ],
  
})
export class CreateQrCodeModule { }
