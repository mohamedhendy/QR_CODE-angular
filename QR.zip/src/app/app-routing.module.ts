import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './pages/layout/layout.component';

const routes: Routes = [
  {
    path: 'login',
    loadChildren: () =>
      import('./auth/login/login.module').then((m) => m.LoginModule),
  },
  {path: '', 
  loadChildren: () =>
  import('./auth/login/login.module').then((m) => m.LoginModule),
},
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: 'createQrCode',
        loadChildren: () =>
          import('./pages/create-qr-code/create-qr-code.module').then(
            (m) => m.CreateQrCodeModule
          ),
      },
      {
        path: 'dashboard',
        loadChildren: () =>
          import('./pages/dashboard/dashboard.module').then(
            (m) => m.DashboardModule
          ),
      },
    ],
  },
  {
    path: 'createQrCode',
    loadChildren: () =>
      import('./pages/create-qr-code/create-qr-code.module').then(
        (m) => m.CreateQrCodeModule
      ),
  },
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
