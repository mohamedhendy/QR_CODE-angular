import {  Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "src/environments/environment";
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UrlService {
  [x: string]: any;
  constructor(private http: HttpClient,) { }
  QRImage = '';
  QRImageID = '';
  designData:any = '';
  private messageSource = new BehaviorSubject<any>('');
  private imageSource = new BehaviorSubject<any>('');
  private patternDesignSource = new BehaviorSubject<any>('');
  patternDesign= this.patternDesignSource.asObservable();
  imageID = this.imageSource.asObservable();
  currentMessage = this.messageSource.asObservable();
  mData:any;
  getData(data:any, nameRoute:any) {
    var accessToken = localStorage.getItem('access-token')
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        Authorization: String(accessToken)
      })
    };
    var body = JSON.stringify(data);
    return this.http.post(environment.apiUrl + nameRoute ,body, httpOptions ).subscribe( (result:any) => {
      console.log(body);
        this.QRImage = result.QRCode.qrImage;
        this.QRImageID = result.QRCode._id
    },  error => {
      this.QRImage = ''
      this.QRImageID = ''
    },() => {
      // No errors, route to new page here
    });
  }
  changeMessage() {
    this.messageSource.next(this.QRImage)
    this.imageSource.next(this.QRImageID)
  }
  changePatternDesign() {
    this.patternDesignSource.next(this.designData)
  }
  getDesignPatternData(designData:any) {
    this.patternDesignSource.next(designData)
  }
}
