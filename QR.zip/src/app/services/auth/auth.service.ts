import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from '@angular/core';
import { Router } from "@angular/router";
import { environment } from "src/environments/environment";
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public user: any = null;
  public apiUrlExt: any;
  public scope:any;
  public menu:any;
  public username: string | undefined;

  constructor(private http: HttpClient, private router: Router) {}

  public setUser(user:any) {
      localStorage.setItem("access-token", user["token"]);
      localStorage.setItem("companyId", user["comapnyId"]);
      this.user = user;
      this.scope = user.scope;
  }



  public loginUser(username:any, password:any, role:any) {
      this.username = username;
      if (role == "SuperAdmin") {
          this.apiUrlExt = "superadmin/login";
      } else if (role == "CompanyAdmin") {
          this.apiUrlExt = "company/login";
      }

      return this.http.post(environment.apiUrl + this.apiUrlExt, {
          username: username,
          password: password,
      });
  }

  public logOut() {
      this.router.navigate(["/"]);
  }
}
