import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
@Component({
  selector: 'app-youtube-barcode',
  templateUrl: './youtube-barcode.component.html',
  styleUrls: ['./youtube-barcode.component.scss']
})
export class YoutubeBarcodeComponent implements OnInit {

  constructor( private insta: FormBuilder ) { }

  barcodeForm = this.insta.group({
    videoID: ['', Validators.required],
    youtubeID: ['', ],
    tags: ['', Validators.required],
    qrPlace: ['', Validators.required],
    dynamicUrl: ['', Validators.required],
    staticUrl: ['', Validators.required],
    })
  ngOnInit(): void {
  }

  
  onSubmit() {
    console.warn(this.barcodeForm.value);
  }

}
