import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
@Component({
  selector: 'app-instagram-barcode',
  templateUrl: './instagram-barcode.component.html',
  styleUrls: ['./instagram-barcode.component.scss']
})
export class InstagramBarcodeComponent implements OnInit {

  constructor( private insta: FormBuilder ) { }

  instaForm = this.insta.group({
    instaUrl: ['', Validators.required],
    tags: [''],
    qrPlace: [''],
    dynamicUrl: [''],
    staticUrl: [''],
    
    })
  ngOnInit(): void {
  }

  
  onSubmit() {
    console.warn(this.instaForm.value);
  }
}
