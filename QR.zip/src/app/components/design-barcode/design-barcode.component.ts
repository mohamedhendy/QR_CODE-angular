import { Component, OnInit } from '@angular/core';

import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
} from '@angular/forms';
import { UrlService } from 'src/app/services/url/url.service';
@Component({
  selector: 'app-design-barcode',
  templateUrl: './design-barcode.component.html',
  styleUrls: ['./design-barcode.component.scss'],
})
export class DesignBarcodeComponent implements OnInit {
  designData:any;
  constructor(
    private designFormF: FormBuilder,
    private urlServices: UrlService
  ) {}
  designForm = this.designFormF.group({
    frontcolor: [''],
    backcolor: [''],
    radial: ['on'],
    gradient: ['on'],
    gradient_color: [''],
    pattern: [''],
    marker: [''],
    marker_in: [''],
    optionlogo: [''],
    outer_frame: [''],
  });
  
  onChange() {
    this.urlServices.getDesignPatternData(this.designForm.value);
  }
  onSubmit() {
    console.warn(this.designForm.value);
  }
  ngOnInit(): void {
    this.urlServices.patternDesign.subscribe(res => this.designData = this.designForm.value)
  }
}
