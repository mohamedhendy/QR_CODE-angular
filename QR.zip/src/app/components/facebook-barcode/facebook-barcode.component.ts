import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
@Component({
  selector: 'app-facebook-barcode',
  templateUrl: './facebook-barcode.component.html',
  styleUrls: ['./facebook-barcode.component.scss']
})
export class FacebookBarcodeComponent implements OnInit {

 constructor( private facebook: FormBuilder ) { }

  barcodeForm = this.facebook.group({
    facebookUrl: ['', Validators.required],
    tags: ['', Validators.required],
    qrPlace: ['', Validators.required],
    dynamicUrl: ['', Validators.required],
    staticUrl: ['', Validators.required],
    })
  ngOnInit(): void {
  }

  
  onSubmit() {
    console.warn(this.barcodeForm.value);
  }

}
