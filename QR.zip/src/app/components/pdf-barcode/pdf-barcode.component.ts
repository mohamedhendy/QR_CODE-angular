import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
@Component({
  selector: 'app-pdf-barcode',
  templateUrl: './pdf-barcode.component.html',
  styleUrls: ['./pdf-barcode.component.scss']
})
export class PdfBarcodeComponent implements OnInit {

constructor( private pdf: FormBuilder ) { }

  barcodeForm = this.pdf.group({
    pdfUrl: ['', ],
    pdfFile: ['', ],
    tags: ['', Validators.required],
    qrPlace: ['', Validators.required],
    dynamicUrl: ['', Validators.required],
    staticUrl: ['', Validators.required],
    
    })
  ngOnInit(): void {
  }

  
  onSubmit() {
    console.warn(this.barcodeForm.value);
  }
}
