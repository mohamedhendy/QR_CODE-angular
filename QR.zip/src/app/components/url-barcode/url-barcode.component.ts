import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
import { UrlService } from 'src/app/services/url/url.service';

@Component({
  selector: 'app-url-barcode',
  templateUrl: './url-barcode.component.html',
  styleUrls: ['./url-barcode.component.scss']
})
export class UrlBarcodeComponent implements OnInit {
  message:any;
  designData:any = '';
  constructor( private urlF: FormBuilder,private urlServices:UrlService ) { }
  urlForm = this.urlF.group({
    url: ['', Validators.required],
    barcodeName: [''],
    tags: [''],
    qrPlace: [''],
    dynamicUrl: [''],
    staticUrl: [''],
    
    })
    
  ngOnInit(): void {
    this.urlServices.currentMessage.subscribe(message => this.message = message);
    this.urlServices.patternDesign.subscribe(res => this.designData = res)
  }
  getUrlQRCode() {
    var self = this;
    var body =  this.urlForm.value;
    var nameRoute = "v2/generate/qr/url";
    var design = this.designData
    var QrBody = {...body, ...design}
    console.log(QrBody);
    this.urlServices.getData(QrBody, nameRoute);
    this.urlServices.changeMessage(); 
  }

  onSubmit() {
    console.warn(this.urlForm.value);
  }
}
