import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
@Component({
  selector: 'app-text-barcode',
  templateUrl: './text-barcode.component.html',
  styleUrls: ['./text-barcode.component.scss']
})
export class TextBarcodeComponent implements OnInit {

constructor( private text: FormBuilder ) { }

  barcodeForm = this.text.group({
    textUrl: ['', Validators.required],
    tags: ['', ],
    message: ['', ],
    dynamicUrl: ['', ],
    staticUrl: ['', ],
    
    })
  ngOnInit(): void {
  }

  
  onSubmit() {
    console.warn(this.barcodeForm.value);
  }

}
