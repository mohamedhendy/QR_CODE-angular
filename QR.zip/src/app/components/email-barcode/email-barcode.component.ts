import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
@Component({
  selector: 'app-email-barcode',
  templateUrl: './email-barcode.component.html',
  styleUrls: ['./email-barcode.component.scss']
})
export class EmailBarcodeComponent implements OnInit {


constructor( private email: FormBuilder ) { }

  barcodeForm = this.email.group({
    emailUrl: ['', Validators.required],
    tags: ['', ],
    message: ['', ],
    dynamicUrl: ['', ],
    staticUrl: ['', ],
    
    })
  ngOnInit(): void {
  }

  
  onSubmit() {
    console.warn(this.barcodeForm.value);
  }


}
