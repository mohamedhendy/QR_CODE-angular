import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
@Component({
  selector: 'app-linkedin-barcode',
  templateUrl: './linkedin-barcode.component.html',
  styleUrls: ['./linkedin-barcode.component.scss']
})
export class LinkedinBarcodeComponent implements OnInit {

 constructor( private linkedin: FormBuilder ) { }

  barcodeForm = this.linkedin.group({
    linkedinUrl: ['', Validators.required],
    tags: [''],
    qrPlace: [''],
    dynamicUrl: [''],
    staticUrl: [''],
    
    })
  ngOnInit(): void {
  }

  
  onSubmit() {
    console.warn(this.barcodeForm.value);
  }

}
