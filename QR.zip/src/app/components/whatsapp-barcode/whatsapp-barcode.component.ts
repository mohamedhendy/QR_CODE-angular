import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';

@Component({
  selector: 'app-whatsapp-barcode',
  templateUrl: './whatsapp-barcode.component.html',
  styleUrls: ['./whatsapp-barcode.component.scss']
})
export class WhatsappBarcodeComponent implements OnInit {

  constructor( private insta: FormBuilder ) { }

  instaForm = this.insta.group({
    instaUrl: ['', Validators.required],
    messageUrl: ['', ],
    tags: ['', Validators.required],
    qrPlace: ['', Validators.required],
    dynamicUrl: ['', Validators.required],
    staticUrl: ['', Validators.required],
    })
  ngOnInit(): void {
  }

  
  onSubmit() {
    console.warn(this.instaForm.value);
  }

}
