import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
@Component({
  selector: 'app-twitter-barcode',
  templateUrl: './twitter-barcode.component.html',
  styleUrls: ['./twitter-barcode.component.scss']
})
export class TwitterBarcodeComponent implements OnInit {

 constructor( private twitter: FormBuilder ) { }

  barcodeForm = this.twitter.group({
    twitterUrl: ['', Validators.required],
    tags: ['', Validators.required],
    qrPlace: ['', Validators.required],
    dynamicUrl: ['', Validators.required],
    staticUrl: ['', Validators.required],
    
    })
  ngOnInit(): void {
  }

  
  onSubmit() {
    console.warn(this.barcodeForm.value);
  }

}
