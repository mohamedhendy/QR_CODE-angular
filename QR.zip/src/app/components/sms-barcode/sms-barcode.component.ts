import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';

@Component({
  selector: 'app-sms-barcode',
  templateUrl: './sms-barcode.component.html',
  styleUrls: ['./sms-barcode.component.scss']
})
export class SmsBarcodeComponent implements OnInit {

  constructor( private email: FormBuilder ) { }

  barcodeForm = this.email.group({
    mobileUrl: ['', Validators.required],
    tags: ['', ],
    message: ['', ],
    dynamicUrl: ['', ],
    staticUrl: ['', ],
    })
  ngOnInit(): void {
  }
  onSubmit() {
    console.warn(this.barcodeForm.value);
  }
}
