import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
@Component({
  selector: 'app-mp3-barcode',
  templateUrl: './mp3-barcode.component.html',
  styleUrls: ['./mp3-barcode.component.scss']
})
export class Mp3BarcodeComponent implements OnInit {

  constructor( private mp3: FormBuilder ) { }

  barcodeForm = this.mp3.group({
    mp3Url: ['', ],
    mp3File: ['', ],
    tags: ['', Validators.required],
    qrPlace: ['', Validators.required],
    dynamicUrl: ['', Validators.required],
    staticUrl: ['', Validators.required],
    
    })
  ngOnInit(): void {
  }

  
  onSubmit() {
    console.warn(this.barcodeForm.value);
  }

}
