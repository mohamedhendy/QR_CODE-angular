import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
@Component({
  selector: 'app-phone-barcode',
  templateUrl: './phone-barcode.component.html',
  styleUrls: ['./phone-barcode.component.scss']
})
export class PhoneBarcodeComponent implements OnInit {

constructor( private phone: FormBuilder ) { }

  barcodeForm = this.phone.group({
    phoneUrl: ['', Validators.required],
    tags: ['', Validators.required],
    qrPlace: ['', Validators.required],
    dynamicUrl: ['', Validators.required],
    staticUrl: ['', Validators.required],
    
    })
  ngOnInit(): void {
  }

  
  onSubmit() {
    console.warn(this.barcodeForm.value);
  }

}
