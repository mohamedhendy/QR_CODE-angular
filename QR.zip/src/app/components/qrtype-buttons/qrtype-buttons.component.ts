import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qrtype-buttons',
  templateUrl: './qrtype-buttons.component.html',
  styleUrls: ['./qrtype-buttons.component.scss']
})
export class QRTypeButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
