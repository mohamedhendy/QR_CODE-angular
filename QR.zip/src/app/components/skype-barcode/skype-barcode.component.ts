import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
@Component({
  selector: 'app-skype-barcode',
  templateUrl: './skype-barcode.component.html',
  styleUrls: ['./skype-barcode.component.scss']
})
export class SkypeBarcodeComponent implements OnInit {

constructor( private skype: FormBuilder ) { }

  barcodeForm = this.skype.group({
    skypeUrl: ['', Validators.required],
    tags: ['', Validators.required],
    qrPlace: ['', Validators.required],
    dynamicUrl: ['', Validators.required],
    staticUrl: ['', Validators.required],
    
    })
  ngOnInit(): void {
  }

  
  onSubmit() {
    console.warn(this.barcodeForm.value);
  }

}
