import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
@Component({
  selector: 'app-vcard-barcode',
  templateUrl: './vcard-barcode.component.html',
  styleUrls: ['./vcard-barcode.component.scss']
})
export class VcardBarcodeComponent implements OnInit {

 constructor( private facebook: FormBuilder ) { }

  barcodeForm = this.facebook.group({
    salutaion: ['', Validators.required],
    suffix: ['', Validators.required],
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    jobPosition: ['', Validators.required],
    company: ['', Validators.required],
    email: ['', Validators.required],
    website: ['', Validators.required],
    phone: ['', Validators.required],
    mobile: ['', Validators.required],
    phoneHome: ['', Validators.required],
    fax: ['', Validators.required],
    business: ['', Validators.required],
    Zip: ['', Validators.required],
    street: ['', Validators.required],
    city: ['', Validators.required],
    state: ['', Validators.required],
    country: ['', Validators.required],
    note: ['', Validators.required],
    tags: [''],
  })
  ngOnInit(): void {
  }
  onSubmit() {
    console.warn(this.barcodeForm.value);
  }
}