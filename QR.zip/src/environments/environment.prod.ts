export const environment = {
  production: true,
  apiUrl: "https://app.letsqr.com/api/"
};
